<link rel="stylesheet" type="text/css" href="/template/public/lightbox/css/lightbox.min.css">
<script src="/template/public/lightbox/js/lightbox.min.js"></script>

<link rel="stylesheet" type="text/css" href="/template/public/owl/owl.carousel.min.css">
<link rel="stylesheet" type="text/css" href="/template/public/owl/owl.theme.default.min.css">
<script src="/template/public/owl/owl.carousel.min.js"></script>


<div class="yandex-map" id="map"></div>

<script src="https://api-maps.yandex.ru/2.1.56/?lang=ru_RU"></script>

<script src="/template/public/js/boards.js"></script>
