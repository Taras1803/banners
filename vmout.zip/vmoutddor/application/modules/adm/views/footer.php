
                    </div>
                </div>
            </div>

            <div class="modal-bg hidden"></div>

            <footer>
                <div class="page-footer-inner">
                    2017 &copy; VM Admin Panel By <a href="http://havrilow.ru" title="Anton Gavrilov" target="_blank">Anton Gavrilov</a> from <a href="http://vostok-digital.ru" title="Vostok-digital" target="_blank">Vostok-Digital</a>
                </div>
            </footer>
        
        </div>

    </body>

</html>